package com.air_traffic_system.AirTrafficSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirTrafficSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
